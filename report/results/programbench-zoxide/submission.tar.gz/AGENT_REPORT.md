# Agent Report

## What was implemented

A from-scratch reimplementation of `zoxide 0.9.9` in Python (src/main.py) with:
- CLI parsing for subcommands: add, edit, import, init, query, remove (+ help/version)
- Exact help/version text matching observed output
- db.zo binary format: header `u32 version=3, u32 count, 4 zero bytes`, then per entry
  `u64 path_len, path bytes, f64 score, u64 last_accessed`
- `add`: increments score for existing path (timestamp unchanged), inserts new entries
  (score default 1), excludes `_ZO_EXCLUDE_DIRS`, resolves symlinks if
  `_ZO_RESOLVE_SYMLINKS=1`
- `query`: frecency ranking with Mozilla-style buckets:
  - age < 3600s: score*4
  - age < 86400s: score*2
  - age < 604800s: score*0.5
  - else: score*0.25
  - Sort by (score desc, db index desc). Filters non-existent dirs unless `-a`.
  - Supports `-l`, `-s`, `--exclude`, `--base-dir`, `-i` (fzf)
- `remove`: removes matching paths (or fzf interactive if no args)
- `import`: z and autojump formats
- `edit`: writes text file, opens $EDITOR, parses back
- `init`: exact captured templates for all 9 shells (default pwd/z/cmd).
  Variants for bash/zsh/fish/posix with --cmd j / --hook prompt / --no-cmd none
  are captured; other combinations fall back to the default template (see below).

## Known limitations / TODO

1. **init variants**: only the default (hook=pwd, cmd=z, cmd-defined) templates are
   exact for all shells, plus captured variants for bash/zsh/fish/posix
   (`cmd j + hook prompt`, `no-cmd + hook none`). Other combinations
   (e.g., `--hook none` with cmd defined, `--cmd X` with other hooks, powershell/etc.
   variants) fall back to the default template, which is NOT byte-identical to the
   original. Should capture all 9 shells × 3 hooks × cmd/no-cmd variants.

2. **Aging algorithm**: observed removal counts don't match a simple
   `while count > max_age: remove oldest`. Observed kept counts:
   - max=50, added 100 -> kept 49 (d52..d100)
   - max=10, added 30 -> kept 8 (d23..d30)
   - max=20, added 60 -> kept 18 (d43..d60)
   Current implementation keeps `max_age` entries (removes oldest while count > max).
   The real algorithm appears to remove `(added-max) + (floor(added/max)-1)` entries,
   i.e., kept = max - floor(added/max) + 1. Needs investigation.

3. **query keyword matching**: implemented as substring match; `keyword/` prefix match
   on path components is approximated. Exact fuzzy-matching details (e.g., handling of
   `/` in keywords, case sensitivity) need more testing.

4. **remove/import/edit edge cases**: may differ from original in error messages and
   exact behavior (e.g., import merge flag semantics, remove of non-normalized paths).

5. **`_ZO_ECHO`**: not yet used in query output; the init scripts read it at runtime,
   so the Rust binary's query output may not change, but the shell scripts' `__zoxide_cd`
   may include echo logic depending on env at init time (needs verification).

6. The compiled `./executable` is a Python script (requires python3). compile.sh
   regenerates it from src/main.py and copies src/init_templates to ./init_templates.

## How to build

```
./compile.sh
```
Produces `./executable` in the workspace root.
