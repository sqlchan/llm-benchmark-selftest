# zoxide

**zoxide** is a smarter cd command, inspired by z and autojump.

It remembers which directories you use most frequently, so you can "jump" to them in just a few keystrokes.

## What does zoxide do?

zoxide keeps track of the directories you use most frequently, and uses a ranking algorithm to navigate to the best match.

## Usage Examples

```sh
z foo              # cd into highest ranked directory matching foo
z foo bar          # cd into highest ranked directory matching foo and bar
z foo /            # cd into a subdirectory starting with foo

z ~/foo            # z also works like a regular cd command
z foo/             # cd into relative path
z ..               # cd one level up
z -                # cd into previous directory

zi foo             # cd with interactive selection (using fzf)

z foo<SPACE><TAB>  # show interactive completions (bash 4.4+/fish/zsh only)
```

## Installation

zoxide can be installed on Linux, macOS, Windows, BSD, and Android through various package managers.

### Linux / WSL

Install using your distribution's package manager or via:

```sh
curl -sSfL https://raw.githubusercontent.com/ajeetdsouza/zoxide/main/install.sh | sh
```

Available in package repositories for:
- Alpine Linux 3.13+: `apk add zoxide`
- Arch Linux: `pacman -S zoxide`
- Fedora 32+: `dnf install zoxide`
- Gentoo: `emerge app-shells/zoxide`
- openSUSE Tumbleweed: `zypper install zoxide`
- Void Linux: `xbps-install -S zoxide`

And many others. See distribution documentation for details.

### macOS

Install using Homebrew or other package managers:

```sh
brew install zoxide
```

Or use the install script:

```sh
curl -sSfL https://raw.githubusercontent.com/ajeetdsouza/zoxide/main/install.sh | sh
```

### Windows

Install using winget:

```sh
winget install ajeetdsouza.zoxide
```

Or use alternative package managers:
- Chocolatey: `choco install zoxide`
- Scoop: `scoop install zoxide`

### BSD

Install using your distribution's package manager:

- DragonFly BSD: `pkg install zoxide`
- FreeBSD: `pkg install zoxide`
- NetBSD: `pkgin install zoxide`

Or use the install script:

```sh
curl -sS https://raw.githubusercontent.com/ajeetdsouza/zoxide/main/install.sh | bash
```

### Android

Install using Termux:

```sh
pkg install zoxide
```

## Setup

After installation, add zoxide to your shell configuration:

### Bash

Add to the end of `~/.bashrc`:

```sh
eval "$(zoxide init bash)"
```

### Zsh

Add to the end of `~/.zshrc`:

```sh
eval "$(zoxide init zsh)"
```

For completions to work, this must be added after `compinit` is called.

### Fish

Add to the end of `~/.config/fish/config.fish`:

```sh
zoxide init fish | source
```

### PowerShell

Add to the end of your PowerShell profile (find it by running `echo $profile`):

```powershell
Invoke-Expression (& { (zoxide init powershell | Out-String) })
```

### Elvish

Add to the end of `~/.elvish/rc.elv`:

```sh
eval (zoxide init elvish | slurp)
```

(Requires elvish v0.18.0+)

### Nushell

Add to the end of your env file (find it by running `$nu.env-path`):

```sh
zoxide init nushell | save -f ~/.zoxide.nu
```

Add to the end of your config file (find it by running `$nu.config-path`):

```sh
source ~/.zoxide.nu
```

(Requires Nushell v0.89.0+)

### Other shells

For other POSIX-compatible shells, add to your config file:

```sh
eval "$(zoxide init posix --hook prompt)"
```

## Configuration

### Command Flags

When running `zoxide init`, the following flags are available:

- `--cmd`: Changes the prefix of the `z` and `zi` commands
  - Example: `--cmd j` changes commands to `j` and `ji`
  - Example: `--cmd cd` replaces the `cd` command

- `--hook <HOOK>`: Changes how often zoxide increments a directory's score
  - `none`: Never
  - `prompt`: At every shell prompt
  - `pwd` (default): Whenever the directory is changed

- `--no-cmd`: Prevents zoxide from defining `z` and `zi` commands
  - Functions remain available as `__zoxide_z` and `__zoxide_zi`

### Environment Variables

Environment variables can be set before calling `zoxide init` to configure behavior:

#### `_ZO_DATA_DIR`

Specifies the directory where the database is stored.

Default values:
- **Linux / BSD**: `$XDG_DATA_HOME` or `$HOME/.local/share`
- **macOS**: `$HOME/Library/Application Support`
- **Windows**: `%LOCALAPPDATA%`

#### `_ZO_ECHO`

When set to 1, `z` will print the matched directory before navigating to it.

#### `_ZO_EXCLUDE_DIRS`

Excludes specified directories from the database.

Provided as a list of globs separated by OS-specific characters:
- **Linux / macOS / BSD**: `:` (colon), e.g., `$HOME:$HOME/private/*`
- **Windows**: `;` (semicolon), e.g., `$HOME;$HOME/private/*`

Default: `$HOME`

#### `_ZO_FZF_OPTS`

Custom options to pass to fzf during interactive selection.

#### `_ZO_MAXAGE`

Configures the aging algorithm, which limits the maximum number of entries in the database.

Default: 10000

#### `_ZO_RESOLVE_SYMLINKS`

When set to 1, `z` will resolve symlinks before adding directories to the database.

## Subcommands

- `zoxide add`: Add a new directory to the database, or increment its rank
- `zoxide import`: Import entries from another application
- `zoxide init`: Generate shell configuration
- `zoxide query`: Search for a directory in the database
- `zoxide remove`: Remove a directory from the database

## Importing Data

If you currently use autojump, fasd, z, z.lua, zsh-z, or ZLocation, you can import your data:

```sh
zoxide import --from=autojump "/path/to/autojump/db"
zoxide import --from=z "/path/to/z/db"
```

## Third-party Integrations

zoxide integrates with many applications:

- **File managers**: felix, joshuto, lf, nnn, ranger, rfm, xplr, yazi
- **Editors**: emacs, vim, neovim
- **Launchers**: alfred (macOS), raycast (macOS)
- **Shell enhancements**: clink (Windows), zsh-autocomplete
- **Terminal multiplexers**: tmux integrations (sesh, tmux-session-wizard, tmux-sessionx, zesh)
- **Other tools**: aerc, telescope.nvim, xxh, zabb

## How It Works

zoxide tracks directory usage and assigns each directory a score. When you run `z`, it matches your query against the database and navigates to the best match based on:

- How frequently you visit the directory
- How recently you visited it
- How well the query matches the directory path

The matching algorithm supports:
- Multiple keywords: `z foo bar` matches directories containing both "foo" and "bar"
- Fuzzy matching: Keywords can match anywhere in the path
- Prefix matching: Adding `/` restricts matching to directory prefixes

## Requirements

- For interactive selection (`zi`): fzf v0.51.0 or later (optional)

## License

See LICENSE file for details.
