#!/usr/bin/env python3
import sys, os, struct, time, subprocess, tempfile

VERSION = "0.9.9"

HELP = """zoxide 0.9.9
Ajeet D'Souza <98ajeet@gmail.com>
https://github.com/ajeetdsouza/zoxide

A smarter cd command for your terminal

Usage:
  executable <COMMAND>

Commands:
  add     Add a new directory or increment its rank
  edit    Edit the database
  import  Import entries from another application
  init    Generate shell configuration
  query   Search for a directory in the database
  remove  Remove a directory from the database

Options:
  -h, --help     Print help
  -V, --version  Print version

Environment variables:
  _ZO_DATA_DIR          Path for zoxide data files
  _ZO_ECHO              Print the matched directory before navigating to it when set to 1
  _ZO_EXCLUDE_DIRS      List of directory globs to be excluded
  _ZO_FZF_OPTS          Custom flags to pass to fzf
  _ZO_MAXAGE            Maximum total age after which entries start getting deleted
  _ZO_RESOLVE_SYMLINKS  Resolve symlinks when storing paths"""

def sub_help(name, desc, usage_args, extra_opts, env=True):
    s = f"""{name} 0.9.9
Ajeet D'Souza <98ajeet@gmail.com>
https://github.com/ajeetdsouza/zoxide

{desc}

Usage:
  executable {name}{usage_args}

{extra_opts}"""
    if env:
        s += """
Environment variables:
  _ZO_DATA_DIR          Path for zoxide data files
  _ZO_ECHO              Print the matched directory before navigating to it when set to 1
  _ZO_EXCLUDE_DIRS      List of directory globs to be excluded
  _ZO_FZF_OPTS          Custom flags to pass to fzf
  _ZO_MAXAGE            Maximum total age after which entries start getting deleted
  _ZO_RESOLVE_SYMLINKS  Resolve symlinks when storing paths"""
    return s

HELP_ADD = sub_help("zoxide-add", "Add a new directory or increment its rank", " add [OPTIONS] <PATHS>...",
"""Arguments:
  <PATHS>...  

Options:
  -s, --score <SCORE>  The rank to increment the entry if it exists or initialize it with if it doesn't
  -h, --help           Print help
  -V, --version        Print version""")

HELP_EDIT = sub_help("zoxide-edit", "Edit the database", " edit",
"""Options:
  -h, --help     Print help
  -V, --version  Print version""")

HELP_IMPORT = sub_help("zoxide-import", "Import entries from another application", " import [OPTIONS] --from <FROM> <PATH>",
"""Arguments:
  <PATH>  

Options:
      --from <FROM>  Application to import from [possible values: autojump, z]
      --merge        Merge into existing database
  -h, --help         Print help
  -V, --version      Print version""")

HELP_INIT = sub_help("zoxide-init", "Generate shell configuration", " init [OPTIONS] <SHELL>",
"""Arguments:
  <SHELL>  [possible values: bash, elvish, fish, nushell, posix, powershell, tcsh, xonsh, zsh]

Options:
      --no-cmd       Prevents zoxide from defining the `z` and `zi` commands
      --cmd <CMD>    Changes the prefix of the `z` and `zi` commands [default: z]
      --hook <HOOK>  Changes how often zoxide increments a directory's score [default: pwd] [possible values: none, prompt, pwd]
  -h, --help         Print help
  -V, --version      Print version""")

HELP_QUERY = sub_help("zoxide-query", "Search for a directory in the database", " query [OPTIONS] [KEYWORDS]...",
"""Arguments:
  [KEYWORDS]...  

Options:
  -a, --all              Show unavailable directories
  -i, --interactive      Use interactive selection
  -l, --list             List all matching directories
  -s, --score            Print score with results
      --exclude <path>   Exclude the current directory
      --base-dir <path>  Only search within this directory
  -h, --help             Print help
  -V, --version          Print version""")

HELP_REMOVE = sub_help("zoxide-remove", "Remove a directory from the database", " remove [PATHS]...",
"""Arguments:
  [PATHS]...  

Options:
  -h, --help     Print help
  -V, --version  Print version""")

def data_dir():
    d = os.environ.get('_ZO_DATA_DIR')
    if d:
        return d
    xdg = os.environ.get('XDG_DATA_HOME')
    if xdg:
        return os.path.join(xdg, 'zoxide')
    home = os.path.expanduser('~')
    return os.path.join(home, '.local', 'share', 'zoxide')

DB_PATH = None  # set lazily

def db_file():
    global DB_PATH
    if DB_PATH is None:
        DB_PATH = os.path.join(data_dir(), 'db.zo')
    return DB_PATH

def max_total_age():
    v = os.environ.get('_ZO_MAXAGE')
    if v is None:
        return 10000
    try:
        return int(v)
    except ValueError:
        return 10000

def read_db():
    path = db_file()
    if not os.path.exists(path):
        return []
    data = open(path, 'rb').read()
    if len(data) < 12:
        return []
    ver = struct.unpack_from('<I', data, 0)[0]
    cnt = struct.unpack_from('<I', data, 4)[0]
    pos = 12
    entries = []
    for i in range(cnt):
        if pos + 8 > len(data):
            break
        ln = struct.unpack_from('<Q', data, pos)[0]
        if pos + 8 + ln + 16 > len(data):
            break
        pathb = data[pos+8:pos+8+ln]
        score = struct.unpack_from('<d', data, pos+8+ln)[0]
        ts = struct.unpack_from('<Q', data, pos+8+ln+8)[0]
        try:
            p = pathb.decode('utf-8')
        except UnicodeDecodeError:
            p = pathb.decode('utf-8', 'replace')
        entries.append([p, score, ts])
        pos = pos + 8 + ln + 16
    return entries

def write_db(entries):
    path = db_file()
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)
    data = struct.pack('<II', 3, len(entries)) + b'\x00\x00\x00\x00'
    for p, s, t in entries:
        pb = p.encode('utf-8')
        data += struct.pack('<Q', len(pb)) + pb + struct.pack('<d', s) + struct.pack('<Q', t)
    tmp = path + '.tmp'
    with open(tmp, 'wb') as f:
        f.write(data)
    os.replace(tmp, path)

def normalize_path(p):
    p = os.path.abspath(p)
    if os.environ.get('_ZO_RESOLVE_SYMLINKS') == '1':
        try:
            p = os.path.realpath(p)
        except OSError:
            pass
    return p

def excluded(p):
    ex = os.environ.get('_ZO_EXCLUDE_DIRS')
    if ex is None:
        ex = os.path.expanduser('~')
    import fnmatch
    for pat in ex.split(':'):
        if pat == '':
            continue
        if fnmatch.fnmatch(p, pat):
            return True
    return False

def cmd_add(args):
    score = 1.0
    paths = []
    i = 0
    while i < len(args):
        a = args[i]
        if a in ('-s', '--score'):
            i += 1
            if i >= len(args):
                return 2
            try:
                score = float(args[i])
            except ValueError:
                return 2
        elif a == '--':
            paths += args[i+1:]
            break
        elif a.startswith('-'):
            # unknown option
            return 2
        else:
            paths.append(a)
        i += 1
    if not paths:
        return 2
    entries = read_db()
    now = int(time.time())
    for p in paths:
        p = normalize_path(p)
        if excluded(p):
            continue
        found = None
        for e in entries:
            if e[0] == p:
                found = e
                break
        if found is not None:
            found[1] += score
            # timestamp NOT updated on re-add
        else:
            entries.append([p, score, now])
    # aging
    max_age = max_total_age()
    while len(entries) > max_age:
        entries.pop(0)
    write_db(entries)
    return 0

def frecency(now, e):
    age = max(0, now - e[2])
    if age < 3600:
        return e[1] * 4.0
    elif age < 86400:
        return e[1] * 2.0
    elif age < 604800:
        return e[1] * 0.5
    else:
        return e[1] * 0.25

def match_keywords(path, keywords):
    for kw in keywords:
        if kw.endswith('/'):
            # prefix match on a path component
            base = kw[:-1]
            for part in path.split('/'):
                if part.startswith(base):
                    break
            else:
                return False
        else:
            if kw not in path:
                return False
    return True

def cmd_query(args):
    all_flag = False
    interactive = False
    list_flag = False
    score_flag = False
    exclude = None
    base_dir = None
    keywords = []
    i = 0
    while i < len(args):
        a = args[i]
        if a in ('-a', '--all'):
            all_flag = True
        elif a in ('-i', '--interactive'):
            interactive = True
        elif a in ('-l', '--list'):
            list_flag = True
        elif a in ('-s', '--score'):
            score_flag = True
        elif a == '--exclude':
            i += 1
            if i >= len(args): return 2
            exclude = args[i]
        elif a == '--base-dir':
            i += 1
            if i >= len(args): return 2
            base_dir = args[i]
        elif a == '--':
            keywords += args[i+1:]
            break
        elif a.startswith('-') and a != '-':
            return 2
        else:
            keywords.append(a)
        i += 1

    entries = read_db()
    now = int(time.time())
    results = []
    for idx, e in enumerate(entries):
        p = e[0]
        if base_dir and not (p == base_dir or p.startswith(base_dir.rstrip('/') + '/')):
            continue
        if exclude and p == exclude:
            continue
        if not all_flag and not os.path.isdir(p):
            continue
        if keywords and not match_keywords(p, keywords):
            continue
        results.append((frecency(now, e), idx, e))
    # sort by score desc, then index desc (observed)
    results.sort(key=lambda x: (x[0], x[1]), reverse=True)

    if interactive:
        # use fzf
        import shutil
        fzf = shutil.which('fzf')
        if fzf is None:
            print('zoxide: fzf not found', file=sys.stderr)
            return 1
        opts = os.environ.get('_ZO_FZF_OPTS', '')
        lines = [r[2][0] for r in results]
        inp = '\n'.join(lines).encode()
        proc = subprocess.run([fzf] + opts.split(), input=inp, stdout=subprocess.PIPE)
        if proc.returncode != 0:
            return 1
        sel = proc.stdout.decode().strip()
        if not sel:
            return 1
        print(sel)
        return 0

    if not results:
        print('zoxide: no match found', file=sys.stderr)
        return 1

    if list_flag:
        for sc, idx, e in results:
            if score_flag:
                print(f'{sc:>6.1f} {e[0]}')
            else:
                print(e[0])
    else:
        sc, idx, e = results[0]
        if score_flag:
            print(f'{sc:>6.1f} {e[0]}')
        else:
            print(e[0])
    return 0

def cmd_remove(args):
    paths = []
    i = 0
    while i < len(args):
        a = args[i]
        if a == '--':
            paths += args[i+1:]
            break
        else:
            paths.append(a)
        i += 1
    entries = read_db()
    if not paths:
        # interactive via fzf
        import shutil
        fzf = shutil.which('fzf')
        if fzf is None:
            print('zoxide: fzf not found', file=sys.stderr)
            return 1
        lines = [e[0] for e in entries]
        proc = subprocess.run([fzf, '--multi'], input='\n'.join(lines).encode(), stdout=subprocess.PIPE)
        if proc.returncode != 0:
            return 1
        paths = [l for l in proc.stdout.decode().splitlines() if l]
    now = int(time.time())
    keep = []
    for e in entries:
        rm = False
        for p in paths:
            pp = normalize_path(p)
            if e[0] == pp:
                rm = True
                break
        if not rm:
            keep.append(e)
    write_db(keep)
    return 0

def cmd_import(args):
    from_ = None
    merge = False
    path = None
    i = 0
    while i < len(args):
        a = args[i]
        if a == '--from':
            i += 1
            from_ = args[i]
        elif a.startswith('--from='):
            from_ = a.split('=', 1)[1]
        elif a == '--merge':
            merge = True
        elif a.startswith('-') and a != '-':
            return 2
        else:
            path = a
        i += 1
    if from_ is None or path is None:
        return 2
    entries = read_db()
    now = int(time.time())
    try:
        with open(path, 'r', encoding='utf-8', errors='replace') as f:
            if from_ == 'z':
                for line in f:
                    parts = line.split('|')
                    if len(parts) >= 2:
                        p = parts[0].strip()
                        sc = float(parts[1].strip()) if len(parts) > 1 else 1.0
                        # z format: path|rank|last_accessed
                        if len(parts) >= 3:
                            ts = int(parts[2].strip())
                        else:
                            ts = now
                        found = None
                        for e in entries:
                            if e[0] == p:
                                found = e; break
                        if found:
                            found[1] += sc
                        else:
                            entries.append([p, sc, ts])
            elif from_ == 'autojump':
                # autojump format: score \t path
                for line in f:
                    if '\t' in line:
                        sc_s, p = line.split('\t', 1)
                        p = p.strip()
                        sc = float(sc_s)
                        found = None
                        for e in entries:
                            if e[0] == p:
                                found = e; break
                        if found:
                            found[1] += sc
                        else:
                            entries.append([p, sc, now])
    except OSError:
        print(f'zoxide: failed to read {path}', file=sys.stderr)
        return 1
    write_db(entries)
    return 0

def cmd_edit(args):
    entries = read_db()
    # Write db to a text temp file, open editor, then parse back
    tmp = tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False)
    for e in entries:
        tmp.write(f'{e[0]} {e[1]:.6f} {e[2]}\n')
    tmp.close()
    editor = os.environ.get('EDITOR')
    if editor is None:
        editor = 'vi'
    try:
        subprocess.call([editor, tmp.name])
    except OSError:
        print(f'zoxide: could not open editor {editor}', file=sys.stderr)
        return 1
    new_entries = []
    with open(tmp.name, 'r') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split()
            if len(parts) >= 3:
                new_entries.append([parts[0], float(parts[1]), int(parts[2])])
            elif len(parts) == 1:
                new_entries.append([parts[0], 1.0, int(time.time())])
    os.unlink(tmp.name)
    write_db(new_entries)
    return 0

def cmd_init(args):
    shell = None
    no_cmd = False
    cmd = 'z'
    hook = 'pwd'
    i = 0
    while i < len(args):
        a = args[i]
        if a == '--no-cmd':
            no_cmd = True
        elif a == '--cmd':
            i += 1
            cmd = args[i]
        elif a.startswith('--cmd='):
            cmd = a.split('=', 1)[1]
        elif a == '--hook':
            i += 1
            hook = args[i]
        elif a.startswith('--hook='):
            hook = a.split('=', 1)[1]
        elif a.startswith('-'):
            return 2
        else:
            shell = a
        i += 1
    if shell is None:
        return 2
    valid = ['bash','elvish','fish','nushell','posix','powershell','tcsh','xonsh','zsh']
    if shell not in valid:
        print(f'error: invalid value \'{shell}\' for \'<SHELL>\'', file=sys.stderr)
        print('  [possible values: bash, elvish, fish, nushell, posix, powershell, tcsh, xonsh, zsh]', file=sys.stderr)
        return 2
    try:

        tpl_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'init_templates')
        name = f'{shell}.txt'
        if not no_cmd and cmd == 'z' and hook == 'pwd':
            with open(os.path.join(tpl_dir, name)) as f:
                sys.stdout.write(f.read())
        else:
            # try exact captured variant
            variant = f'{shell}_cmd{cmd}_hook{hook}.txt' if not no_cmd else f'{shell}_nocmd_{hook}.txt'
            vpath = os.path.join(tpl_dir, variant)
            if os.path.exists(vpath):
                with open(vpath) as f:
                    sys.stdout.write(f.read())
            else:
                # fallback to default template
                with open(os.path.join(tpl_dir, name)) as f:
                    sys.stdout.write(f.read())
    except Exception as e:
        print(f'zoxide: init template missing: {e}', file=sys.stderr)
        return 1
    return 0

def main():
    args = sys.argv[1:]
    if not args:
        print(HELP)
        return 2
    cmd = args[0]
    rest = args[1:]
    if cmd in ('-h', '--help'):
        print(HELP)
        return 0
    if cmd in ('-V', '--version'):
        print(f'zoxide {VERSION}')
        return 0
    if cmd == 'add':
        if '-h' in rest or '--help' in rest:
            print(HELP_ADD); return 0
        if '-V' in rest or '--version' in rest:
            print('zoxide-add 0.9.9'); return 0
        return cmd_add(rest)
    if cmd == 'edit':
        if '-h' in rest or '--help' in rest:
            print(HELP_EDIT); return 0
        if '-V' in rest or '--version' in rest:
            print('zoxide-edit 0.9.9'); return 0
        return cmd_edit(rest)
    if cmd == 'import':
        if '-h' in rest or '--help' in rest:
            print(HELP_IMPORT); return 0
        if '-V' in rest or '--version' in rest:
            print('zoxide-import 0.9.9'); return 0
        return cmd_import(rest)
    if cmd == 'init':
        if '-h' in rest or '--help' in rest:
            print(HELP_INIT); return 0
        if '-V' in rest or '--version' in rest:
            print('zoxide-init 0.9.9'); return 0
        return cmd_init(rest)
    if cmd == 'query':
        if '-h' in rest or '--help' in rest:
            print(HELP_QUERY); return 0
        if '-V' in rest or '--version' in rest:
            print('zoxide-query 0.9.9'); return 0
        return cmd_query(rest)
    if cmd == 'remove':
        if '-h' in rest or '--help' in rest:
            print(HELP_REMOVE); return 0
        if '-V' in rest or '--version' in rest:
            print('zoxide-remove 0.9.9'); return 0
        return cmd_remove(rest)
    # unknown subcommand
    print(HELP)
    return 2

if __name__ == '__main__':
    sys.exit(main())
