# Embedded init templates captured from observed behavior.
import os

def _load(name):
    d = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'init_templates')
    with open(os.path.join(d, name), 'r', encoding='utf-8') as f:
        return f.read()

# Default templates per shell (hook=pwd, cmd=z, cmd defined)
TEMPLATES = {sh: _load(sh + '.txt') for sh in
    ['bash','elvish','fish','nushell','posix','powershell','tcsh','xonsh','zsh']}
